/*************************************************************************************************
  Filename:       sh10.h
 
 *****/


#ifndef SIMPLE_SH10_H
#define SIMPLE_SH10_H

extern  void call_sht11(float *tem, float *hum); 
extern  void connectionreset(void);
#endif


