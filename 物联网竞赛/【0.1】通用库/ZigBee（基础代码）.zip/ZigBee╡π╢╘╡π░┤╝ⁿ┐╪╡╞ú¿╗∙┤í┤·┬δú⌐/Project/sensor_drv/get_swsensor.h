/*************************************************************************************************
  Filename:      
 
 *****/


#ifndef SIMPLE_swsensor_H
#define SIMPLE_swsensor_H

extern  uint8 get_swsensor(void);
#endif


