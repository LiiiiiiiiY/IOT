
void MyByteCopy(uint8 *dst, int dststart, uint8 *src, int srcstart, int len);
uint16 RecvUartData(uint8 *uRxData, uint16 uRxlen);
uint16 RecvUart1Data(uint8 *uRxData, uint16 uRxlen);