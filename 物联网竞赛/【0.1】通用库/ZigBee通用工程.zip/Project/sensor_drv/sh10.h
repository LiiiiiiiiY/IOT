/*************************************************************************************************
  Filename:       sh10.h
 
 *****/


#ifndef SIMPLE_SH10_H
#define SIMPLE_SH10_H

extern  void call_sht11(unsigned int *tem, unsigned int *hum); 
extern  void connectionreset(void);
#endif


